package edu.utdallas.foodhunt.usermanagement.businesslayer;

public class Sample {
}
