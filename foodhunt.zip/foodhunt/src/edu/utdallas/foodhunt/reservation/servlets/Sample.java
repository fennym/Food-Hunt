package edu.utdallas.foodhunt.reservation.servlets;

public class Sample {
}
