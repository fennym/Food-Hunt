package edu.utdallas.foodhunt.reservation.businesslayer;

public class Sample {
}
