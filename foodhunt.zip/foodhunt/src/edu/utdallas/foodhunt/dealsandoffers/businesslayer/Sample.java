package edu.utdallas.foodhunt.dealsandoffers.businesslayer;

public class Sample {
}
