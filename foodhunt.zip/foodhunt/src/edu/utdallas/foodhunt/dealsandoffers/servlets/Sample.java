package edu.utdallas.foodhunt.dealsandoffers.servlets;

public class Sample {
}
