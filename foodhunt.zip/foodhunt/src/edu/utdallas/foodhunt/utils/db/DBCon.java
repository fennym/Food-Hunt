package edu.utdallas.foodhunt.utils.db;

public interface DBCon {
    public final String user = "foodhunt";
    public final String password = "ooad_grp3";
    public final String connectionUrl = "jdbc:mysql://den1.mysql5.gear.host:3306/foodhunt";
}
