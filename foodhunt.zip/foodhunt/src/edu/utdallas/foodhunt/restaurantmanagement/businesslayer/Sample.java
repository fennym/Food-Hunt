package edu.utdallas.foodhunt.restaurantmanagement.businesslayer;

public class Sample {
}
