package edu.utdallas.foodhunt.restaurantmanagement.servlets;

public class Sample {
}
